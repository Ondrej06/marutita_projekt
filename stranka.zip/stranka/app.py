from flask import Flask, request, redirect, url_for, render_template, flash
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'tajny_klic'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# 🔹 Model uživatele
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 🔹 Hlavní stránka / dashboard
@app.route("/")
def dashboard():
    users = User.query.all() if current_user.is_authenticated else []
    return render_template("dashboard.html", users=users)

# 🔹 Registrace
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = bcrypt.generate_password_hash(request.form["password"]).decode('utf-8')

        if User.query.filter((User.email==email) | (User.username==username)).first():
            flash("Uživatel s tímto emailem nebo username již existuje.", "danger")
            return redirect(url_for("register"))

        user = User(username=username, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        flash("Registrace proběhla úspěšně. Přihlašte se.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

# 🔹 Přihlášení
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash("Přihlášení proběhlo úspěšně.", "success")
            next_page = request.args.get('next')
            return redirect(next_page or url_for("dashboard"))
        else:
            flash("Neplatný email nebo heslo.", "danger")
    return render_template("login.html")

# 🔹 Odhlášení
@app.route("/logout")
def logout():
    if current_user.is_authenticated:
        logout_user()
        flash("Byl jste odhlášen.", "info")
    return redirect(url_for("dashboard"))

# 🔹 Mazání uživatelů (jen admin)
@app.route("/delete_user/<int:user_id>", methods=["POST"])
def delete_user(user_id):
    if not current_user.is_authenticated or not current_user.is_admin:
        flash("Nemáte oprávnění smazat uživatele.", "danger")
        return redirect(url_for("dashboard"))

    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    flash(f'Uživatel {user.username} ({user.email}) byl smazán.', "success")
    return redirect(url_for('dashboard'))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        # 🔹 Vytvoření admina pokud neexistuje
        if not User.query.filter_by(email="admin@example.com").first():
            admin_password = bcrypt.generate_password_hash("admin123").decode('utf-8')
            admin = User(username="admin", email="admin@example.com", password=admin_password, is_admin=True)
            db.session.add(admin)
            db.session.commit()
    app.run(debug=True)
