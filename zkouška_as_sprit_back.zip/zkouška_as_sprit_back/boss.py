import pygame
import math
import time
import random

pygame.init()
screen = pygame.display.set_mode((1600, 900))
pygame.display.set_caption("Platformer Player + Boss Optimized Laser")
clock = pygame.time.Clock()

# ----- Player properties -----
player_pos = [100.0, 800.0]
player_radius = 25
player_color = (0, 0, 255)
player_speed = 7
player_jump_speed = 15
gravity = 0.8
player_vel_y = 0
on_ground = False

# ----- Boss properties -----
boss_pos = [400.0, 300.0]
boss_radius = 50
boss_color = (255, 0, 0)
boss_speed = 20
wait_duration = 1.0

# Boss path
targets = [
    (479, 337), (1509, 547), (983, 608), (992, 76),
    (479, 337), (1509, 547), (983, 608), (479, 337),
    (1509, 547), (479, 337)
]
current_target_index = 0
waiting = False
wait_start_time = 0

# ----- Projectiles -----
projectiles = []
projectile_speed = 15
projectile_radius = 8
shoot_interval = 1.5
last_shot_time = 0
homing_delay = 0.5
projectiles_per_shot = 15   # snížený počet pro lepší výkon
trail_length = 10           # menší trail pro rychlejší vykreslení

# ----- Platform (ground) -----
ground_y = 850

running = True
while running:
    dt = clock.tick(60) / 1000
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # ----- Player movement -----
    if keys[pygame.K_a] or keys[pygame.K_LEFT]:
        player_pos[0] -= player_speed
    if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
        player_pos[0] += player_speed
    if (keys[pygame.K_w] or keys[pygame.K_UP] or keys[pygame.K_SPACE]) and on_ground:
        player_vel_y = -player_jump_speed
        on_ground = False

    # Gravity
    player_vel_y += gravity
    player_pos[1] += player_vel_y

    # Ground collision
    if player_pos[1] + player_radius >= ground_y:
        player_pos[1] = ground_y - player_radius
        player_vel_y = 0
        on_ground = True

    # ----- Boss movement -----
    if not waiting:
        target_pos = targets[current_target_index]
        dx = target_pos[0] - boss_pos[0]
        dy = target_pos[1] - boss_pos[1]
        distance = math.hypot(dx, dy)

        if distance > boss_speed:
            dx /= distance
            dy /= distance
            boss_pos[0] += dx * boss_speed
            boss_pos[1] += dy * boss_speed
        else:
            boss_pos[0], boss_pos[1] = target_pos
            waiting = True
            wait_start_time = time.time()
    else:
        if time.time() - wait_start_time >= wait_duration:
            current_target_index = (current_target_index + 1) % len(targets)
            waiting = False

    # ----- Boss shooting -----
    if time.time() - last_shot_time >= shoot_interval:
        for _ in range(projectiles_per_shot):
            angle = random.uniform(0, 360)
            rad = math.radians(angle)
            vx = projectile_speed * math.cos(rad)
            vy = projectile_speed * math.sin(rad)
            color = (
                random.randint(50, 255),
                random.randint(50, 255),
                random.randint(50, 255)
            )
            projectiles.append({
                'pos': [boss_pos[0], boss_pos[1]],
                'vel': [vx, vy],
                'spawn_time': time.time(),
                'color': color,
                'homing_done': False,
                'trail': []
            })
        last_shot_time = time.time()

    # ----- Update projectiles -----
    for p in projectiles[:]:
        if not p['homing_done'] and time.time() - p['spawn_time'] >= homing_delay:
            dx = player_pos[0] - p['pos'][0]
            dy = player_pos[1] - p['pos'][1]
            distance = math.hypot(dx, dy)
            if distance != 0:
                dx /= distance
                dy /= distance
                p['vel'][0] = dx * projectile_speed
                p['vel'][1] = dy * projectile_speed
            p['homing_done'] = True

        # Přidání aktuální pozice do trailu
        p['trail'].append((p['pos'][0], p['pos'][1]))
        if len(p['trail']) > trail_length:
            p['trail'].pop(0)

        # Pohyb projektilu
        p['pos'][0] += p['vel'][0]
        p['pos'][1] += p['vel'][1]

        # Odebrání projektilu mimo obrazovku
        if p['pos'][0] < 0 or p['pos'][0] > 1600 or p['pos'][1] < 0 or p['pos'][1] > 900:
            projectiles.remove(p)

    # ----- Draw everything -----
    screen.fill((0, 0, 0))
    # Ground
    pygame.draw.rect(screen, (100, 100, 100), (0, ground_y, 1600, 50))
    # Player
    pygame.draw.circle(screen, player_color, (int(player_pos[0]), int(player_pos[1])), player_radius)
    # Boss
    pygame.draw.circle(screen, boss_color, (int(boss_pos[0]), int(boss_pos[1])), boss_radius)

    # Projectiles with optimized laser-like trail
    for p in projectiles:
        if len(p['trail']) > 1:
            for i in range(1, len(p['trail'])):
                start = p['trail'][i-1]
                end = p['trail'][i]
                # postupně světlejší barva pro efekt paprsku
                factor = i / len(p['trail'])
                color = (
                    int(p['color'][0] * factor),
                    int(p['color'][1] * factor),
                    int(p['color'][2] * factor)
                )
                # pulsující tloušťka podle času
                pulse = 1 + int(2 * math.sin(time.time() * 10 + i))
                width = max(1, int(3 * factor + pulse))
                pygame.draw.line(screen, color, start, end, width)
        # samotný projektil
        pygame.draw.circle(screen, p['color'], (int(p['pos'][0]), int(p['pos'][1])), projectile_radius)

    pygame.display.flip()

pygame.quit()
