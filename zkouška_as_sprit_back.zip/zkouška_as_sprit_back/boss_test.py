# boss.py
import pygame
import math
import time
import random

class Boss:
    def __init__(self, start_pos, targets, speed=20, wait_duration=1.0, projectile_speed=15, projectiles_per_shot=5, trail_length=10):
        self.pos = list(start_pos)
        self.radius = 50
        self.color = (255,0,0)
        self.speed = speed
        self.wait_duration = wait_duration

        self.targets = targets
        self.current_target_index = 0
        self.waiting = False
        self.wait_start_time = 0

        self.projectiles = []
        self.projectile_speed = projectile_speed
        self.projectile_radius = 8
        self.shoot_interval = 1.5
        self.last_shot_time = 0
        self.homing_delay = 0.5
        self.projectiles_per_shot = projectiles_per_shot
        self.trail_length = trail_length

    def update(self, dt, player_pos):
        # ---- Movement ----
        if not self.waiting:
            target_pos = self.targets[self.current_target_index]
            dx = target_pos[0] - self.pos[0]
            dy = target_pos[1] - self.pos[1]
            distance = math.hypot(dx, dy)

            if distance > self.speed:
                dx /= distance
                dy /= distance
                self.pos[0] += dx * self.speed
                self.pos[1] += dy * self.speed
            else:
                self.pos[0], self.pos[1] = target_pos
                self.waiting = True
                self.wait_start_time = time.time()
        else:
            if time.time() - self.wait_start_time >= self.wait_duration:
                self.current_target_index = (self.current_target_index + 1) % len(self.targets)
                self.waiting = False

        # ---- Shooting ----
        if time.time() - self.last_shot_time >= self.shoot_interval:
            for _ in range(self.projectiles_per_shot):
                angle = random.uniform(0, 360)
                rad = math.radians(angle)
                vx = self.projectile_speed * math.cos(rad)
                vy = self.projectile_speed * math.sin(rad)
                color = (
                    random.randint(50,255),
                    random.randint(50,255),
                    random.randint(50,255)
                )
                self.projectiles.append({
                    'pos': [self.pos[0], self.pos[1]],
                    'vel': [vx, vy],
                    'spawn_time': time.time(),
                    'color': color,
                    'homing_done': False,
                    'trail': []
                })
            self.last_shot_time = time.time()

        # ---- Update projectiles ----
        for p in self.projectiles[:]:
            if not p['homing_done'] and time.time() - p['spawn_time'] >= self.homing_delay:
                dx = player_pos[0] - p['pos'][0]
                dy = player_pos[1] - p['pos'][1]
                distance = math.hypot(dx, dy)
                if distance != 0:
                    dx /= distance
                    dy /= distance
                    p['vel'][0] = dx * self.projectile_speed
                    p['vel'][1] = dy * self.projectile_speed
                p['homing_done'] = True

            # Trail
            p['trail'].append((p['pos'][0], p['pos'][1]))
            if len(p['trail']) > self.trail_length:
                p['trail'].pop(0)

            # Move
            p['pos'][0] += p['vel'][0]
            p['pos'][1] += p['vel'][1]

            # Remove off-screen
            if p['pos'][0] < 0 or p['pos'][0] > 1920 or p['pos'][1] < 0 or p['pos'][1] > 1080:
                self.projectiles.remove(p)

    def draw(self, screen):
        # Boss
        pygame.draw.circle(screen, self.color, (int(self.pos[0]), int(self.pos[1])), self.radius)
        # Projectiles with pulsating laser trail
        for p in self.projectiles:
            if len(p['trail']) > 1:
                for i in range(1, len(p['trail'])):
                    start = p['trail'][i-1]
                    end = p['trail'][i]
                    factor = i / len(p['trail'])
                    color = (
                        int(p['color'][0]*factor),
                        int(p['color'][1]*factor),
                        int(p['color'][2]*factor)
                    )
                    pulse = 1 + int(2 * math.sin(time.time()*10 + i))
                    width = max(1, int(3*factor + pulse))
                    pygame.draw.line(screen, color, start, end, width)
            pygame.draw.circle(screen, p['color'], (int(p['pos'][0]), int(p['pos'][1])), self.projectile_radius)
