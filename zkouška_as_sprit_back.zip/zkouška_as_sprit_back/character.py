import pygame

class Character:
    def __init__(self, x, y, scale=2, frame_size=128, ground_y=None):
        self.scale = scale
        self.frame_size = frame_size
        self.ground_y = ground_y

        # Animace: jméno -> (sprite sheet, počet framů)
        self.anim_data = {
            "Attack_1": ("assets/Samurai/Attack_1.png", 6),
            "Attack_2": ("assets/Samurai/Attack_2.png", 4),
            "Attack_3": ("assets/Samurai/Attack_3.png", 3),
            "Dead": ("assets/Samurai/Dead.png", 3),
            "Hurt": ("assets/Samurai/Hurt.png", 2),
            "Idle": ("assets/Samurai/Idle.png", 6),
            "Jump": ("assets/Samurai/Jump.png", 12),
            "Run": ("assets/Samurai/Run.png", 8),
            "Walk": ("assets/Samurai/Walk.png", 8),
        }

        self.animations = {}
        self.current_animation = "Idle"
        self.frames = []
        self.current_frame = 0
        self.animation_speed = 0.2

        self.image = None
        self.rect = None  # Pro sprite
        self.hitbox = None  # základní hitbox
        self.hitbox_attack = None  # hitbox útoku

        self.facing_right = True
        self.x, self.y = x, y
        self.is_jumping = False

        # Hitbox proporce
        self.hit_w = 0.2
        self.hit_h = 0.6
        self.hit_w_utok = 0.2
        self.hit_h_utok = 0.5

        # Útok
        self.attack_active = False

        # Načti animace
        for name, (path, frame_count) in self.anim_data.items():
            self.load_frames_from_sheet(name, path, frame_count)

        # Výchozí animace
        self.set_animation("Idle", force_ground=False)

        # Zajistit, že postava je hned viditelná
        if self.frames:
            self.image = self.frames[0]
            self.rect = self.image.get_rect(topleft=(self.x, self.y))
            self.update_hitbox()

        print("✅ Postava připravena – viditelná od začátku.")

    def load_frames_from_sheet(self, name, sprite_sheet_path, frame_count):
        try:
            sheet = pygame.image.load(sprite_sheet_path).convert_alpha()
        except Exception as e:
            print(f"❌ Nepodařilo se načíst {sprite_sheet_path}: {e}")
            return

        frames = []
        for i in range(frame_count):
            frame = sheet.subsurface(pygame.Rect(i * self.frame_size, 0, self.frame_size, self.frame_size))
            frame = pygame.transform.scale(frame, (self.frame_size * self.scale, self.frame_size * self.scale))
            frames.append(frame)

        self.animations[name] = frames
        print(f"✅ {name} načteno ({len(frames)} framů)")

    def set_animation(self, name, force_ground=False):
        if name in self.animations and name != self.current_animation:
            self.current_animation = name
            self.frames = self.animations[name]
            if self.frames:
                self.current_frame = 0
                self.image = self.frames[0]
                if not self.rect:
                    self.rect = self.image.get_rect(topleft=(self.x, self.y))
                # jen pokud chceme postavit na zem a nejsme ve vzduchu
                if force_ground and self.ground_y and not self.is_jumping:
                    self.rect.bottom = self.ground_y
                self.update_hitbox()

    def set_position(self, x, y):
        self.x, self.y = x, y
        if self.rect:
            self.rect.topleft = (x, y)
            self.update_hitbox()

    # --- Útok ---
    def start_attack(self, attack_name="Attack_1"):
        self.set_animation(attack_name)
        self.attack_active = True
        self.update_attack_hitbox()

    def end_attack(self):
        self.attack_active = False
        self.update_hitbox()

    def update_attack_hitbox(self):
        if self.rect:
            hb_w = int(self.rect.width * self.hit_w_utok)
            hb_h = int(self.rect.height * self.hit_h_utok)
            if self.facing_right:
                hb_x = self.rect.right - 20
            else:
                hb_x = self.rect.left - hb_w + 20
            hb_y = self.rect.bottom - hb_h
            self.hitbox_attack = pygame.Rect(hb_x, hb_y, hb_w, hb_h)

    # --- Hitbox ---
    def update_hitbox(self):
        if self.rect:
            hb_w = int(self.rect.width * self.hit_w)
            hb_h = int(self.rect.height * self.hit_h)
            hb_x = self.rect.x + (self.rect.width - hb_w)//2
            hb_y = self.rect.y + (self.rect.height - hb_h)
            self.hitbox = pygame.Rect(hb_x, hb_y, hb_w, hb_h)
            if self.attack_active:
                self.update_attack_hitbox()

    # --- Animace ---
    def update(self):
        if not self.frames:
            return
        self.current_frame += self.animation_speed
        if self.current_frame >= len(self.frames):
            self.current_frame = 0

        frame = self.frames[int(self.current_frame)]
        if not self.facing_right:
            frame = pygame.transform.flip(frame, True, False)
        self.image = frame
        self.update_hitbox()

    # --- Vykreslení ---
    def draw(self, screen):
        if self.image and self.rect:
            screen.blit(self.image, self.rect)
            # základní hitbox (červený)
            if self.hitbox:
                pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)
            # hitbox útoku (zelený)
            if self.attack_active and self.hitbox_attack:
                pygame.draw.rect(screen, (0, 255, 0), self.hitbox_attack, 2)
