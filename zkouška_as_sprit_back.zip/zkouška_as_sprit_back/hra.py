import pygame
import sys
import math
from character import Character
from nastaveni import SettingsMenu  # tvoje SettingsMenu třída

pygame.init()

# === Výchozí nastavení ===
SCREEN_WIDTH, SCREEN_HEIGHT = 1920, 1080
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Demo")
clock = pygame.time.Clock()

state = "game"

# === Fonty a tlačítka ===
font = pygame.font.SysFont("Arial", 100)
button_font = pygame.font.SysFont("Arial", 50)
button_hover_font = pygame.font.SysFont("Arial", 70)
button_color = (0, 0, 0)
button_hover_color = (50, 50, 50)

def draw_button(rect, text, mouse_pos):
    if rect.collidepoint(mouse_pos):
        pygame.draw.rect(screen, button_hover_color, rect)
        text_surface = button_hover_font.render(text, True, (255, 255, 255))
    else:
        pygame.draw.rect(screen, button_color, rect)
        text_surface = button_font.render(text, True, (255, 255, 255))
    text_rect = text_surface.get_rect(center=rect.center)
    screen.blit(text_surface, text_rect)

def hud(screen, player, potions_left, potion_icon, heart_full, heart_empty):
    total_hearts = int(player.max_health // 10)
    full_hearts = max(0, int(player.health // 10))
    heart_size = 40
    spacing = 10
    start_x = 20
    y = 20

    for i in range(total_hearts):
        x = start_x + i * (heart_size + spacing)
        if heart_full and heart_empty:
            if i < full_hearts:
                screen.blit(heart_full, (x, y))
            else:
                screen.blit(heart_empty, (x, y))
        else:
            color = (255, 0, 0) if i < full_hearts else (40, 40, 40)
            pygame.draw.rect(screen, color, (x, y, heart_size, heart_size))

    potion_area_x = 20
    potion_area_y = y + heart_size + 40
    if potion_icon:
        screen.blit(potion_icon, (potion_area_x, potion_area_y))
    else:
        pygame.draw.circle(screen, (200, 0, 0), (potion_area_x + 30, potion_area_y + 30), 30)

    pot_text = button_font.render(f"x {potions_left}", True, (255, 255, 255))
    screen.blit(pot_text, (potion_area_x + 80, potion_area_y + 10))

def get_ground_y(width):
    if width == 1920: return 950
    elif width == 1600: return 800
    elif width == 1280: return 600
    return 600

ground_y = get_ground_y(SCREEN_WIDTH)
player = Character(400, 0, scale=2.5, frame_size=128, ground_y=ground_y)

# --- Stav ---
player.health = 50
player.max_health = 100
health_potions = 3
health_potion_heal = 30
speed = 5 
run_multiplier = 2
is_jumping = False
jump_speed = 18 
gravity = 1 
velocity_y = 0
attacking = False
attack_cooldown = 0.5
attack_timer = 0

dashing = False
dash_speed = 22
dash_duration = 0.2
dash_timer = 0
dash_cooldown = 1.0
dash_cooldown_timer = 0
dash_trail = []
trail_timer = 0

jump_count = 0
max_jumps = 2

potion_used = False
heal_effect_timer = 0
heal_aura_max_radius = 80

# --- Ikony ---
try:
    potion_icon = pygame.image.load("assets/UI/Transperent/Icon23.png").convert_alpha()
    potion_icon = pygame.transform.scale(potion_icon, (60, 60))
except: potion_icon = None

try:
    heart_full = pygame.image.load("assets/UI/heart.png").convert_alpha()
    heart_empty = pygame.image.load("assets/UI/heart_black.png").convert_alpha()
    heart_full = pygame.transform.scale(heart_full, (40, 40))
    heart_empty = pygame.transform.scale(heart_empty, (40, 40))
except: heart_full = heart_empty = None

# --- Callbacks ---
def on_res_change(res):
    global screen, SCREEN_WIDTH, SCREEN_HEIGHT, ground_y
    SCREEN_WIDTH, SCREEN_HEIGHT = res
    if res == (1920,1080):
        screen = pygame.display.set_mode(res, pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode(res)
    ground_y = get_ground_y(SCREEN_WIDTH)
    player.ground_y = ground_y

def on_vol_change(vol):
    pygame.mixer.music.set_volume(vol)

# === Hlavní smyčka ===
running = True
while running:
    if SCREEN_WIDTH == 1920:
        button_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2+150, 300, 80)
        button2_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2, 300, 80)
        button3_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2-150, 300, 80)
    elif SCREEN_WIDTH == 1600:
        button_rect = pygame.Rect(SCREEN_WIDTH//2-125, SCREEN_HEIGHT//2+125, 300, 80)
        button2_rect = pygame.Rect(SCREEN_WIDTH//2-125, SCREEN_HEIGHT//2, 300, 80)
        button3_rect = pygame.Rect(SCREEN_WIDTH//2-125, SCREEN_HEIGHT//2-125, 300, 80)
    else:
        button_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2+150, 300, 80)
        button2_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2, 300, 80)
        button3_rect = pygame.Rect(SCREEN_WIDTH//2-150, SCREEN_HEIGHT//2-150, 300, 80)

    background = pygame.image.load("assets/Backgrounds/5.png").convert()
    background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
    
    dt = clock.tick(60)/1000
    keys = pygame.key.get_pressed()
    moving = False
    current_speed = speed * (run_multiplier if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] else 1)

    if dash_cooldown_timer > 0:
        dash_cooldown_timer -= dt
        if dash_cooldown_timer < 0: dash_cooldown_timer = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                state = "menu" if state=="game" else "game"
            if state=="game" and event.key==pygame.K_SPACE and jump_count<max_jumps:
                velocity_y = -jump_speed
                is_jumping = True
                jump_count += 1
            if state=="game" and event.key==pygame.K_LCTRL and not dashing and dash_cooldown_timer==0:
                dashing = True
                dash_timer = dash_duration
                dash_cooldown_timer = dash_cooldown
        if state=="menu" and event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            mouse_pos = event.pos
            if button_rect.collidepoint(mouse_pos): running=False
            elif button2_rect.collidepoint(mouse_pos):
                menu = SettingsMenu(SCREEN_WIDTH, SCREEN_HEIGHT)
                menu.set_callbacks(on_res_change, on_vol_change)
                menu.run()
                state="menu"

    # --- Logika hry ---
    if state=="game":
        if not potion_used and keys[pygame.K_f] and health_potions>0:
            potion_used = True
            health_potions -= 1
            player.health += health_potion_heal
            if player.health>player.max_health: player.health=player.max_health
            heal_effect_timer = 1.0
        if not keys[pygame.K_f]: potion_used=False

        # Pohyb
        if not dashing:
            if player.rect and keys[pygame.K_a]:
                player.rect.x -= current_speed
                moving = True
                player.facing_right = False
            if player.rect and keys[pygame.K_d]:
                player.rect.x += current_speed
                moving = True
                player.facing_right = True

        # Dash
        if dashing:
            player.rect.x += dash_speed if player.facing_right else -dash_speed
            trail_timer += dt
            if trail_timer>=0.05:
                trail_timer=0
                dash_trail.append([player.image.copy(), player.rect.topleft, 255])
            dash_timer -= dt
            if dash_timer<=0: dashing=False

        for ghost in dash_trail: ghost[2]-=10
        dash_trail = [g for g in dash_trail if g[2]>0]

        # Gravitační logika
        if player.rect:
            player.rect.y += velocity_y
            velocity_y += gravity
            if player.rect.bottom >= ground_y:
                player.rect.bottom = ground_y
                is_jumping=False
                velocity_y=0
                jump_count=0

        # Útok
        if attack_timer>0: attack_timer-=dt
        else: attack_timer=0
        if not attacking and attack_timer==0:
            if keys[pygame.K_q]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_1")
            elif keys[pygame.K_w]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_2")
            elif keys[pygame.K_e]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_3")
        player.update()
        if attacking:
            if int(player.current_frame)==len(player.frames)-1:
                attacking=False
                player.end_attack()
        # Animace
        if not attacking:
            if is_jumping: player.set_animation("Jump")
            elif moving: player.set_animation("Run" if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] else "Walk")
            else: player.set_animation("Idle")

    # --- Vykreslení ---
    screen.blit(background, (0,0))
    if state=="game":
        hud(screen, player, health_potions, potion_icon, heart_full, heart_empty)

        # Aura + spirála
        if heal_effect_timer>0:
            heal_effect_timer -= dt
            alpha = int((heal_effect_timer/1.0)*150)
            radius = int((1-heal_effect_timer/1.0)*heal_aura_max_radius)+20

            # Aura
            aura_surface = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
            aura_surface.set_alpha(alpha)
            pygame.draw.circle(aura_surface, (0,255,0), (int(radius), int(radius)), int(radius))
            screen.blit(aura_surface, (int(player.rect.centerx-radius), int(player.rect.centery-radius)))

            # Spirálové částice
            particle_surface = pygame.Surface((10,10), pygame.SRCALPHA)
            particle_surface.set_alpha(alpha)
            pygame.draw.circle(particle_surface, (0,255,0), (5,5), 5)
            num_particles=30
            spiral_speed=3
            for i in range(num_particles):
                angle = (pygame.time.get_ticks()/1000*spiral_speed + i*(360/num_particles))%360
                angle_rad = angle*math.pi/180
                particle_radius = radius*(i/num_particles)
                x = int(player.rect.centerx + particle_radius*math.cos(angle_rad))
                y = int(player.rect.centery + particle_radius*math.sin(angle_rad))
                screen.blit(particle_surface, (x-5, y-5))

        # Dash trail
        for ghost_image, pos, alpha in dash_trail:
            surf = ghost_image.copy()
            surf.set_alpha(alpha)
            screen.blit(surf, pos)

        player.draw(screen)

    elif state=="menu":
        menu_text = font.render("MENU", True, (255,0,0))
        screen.blit(menu_text, (screen.get_width()//2 - menu_text.get_width()//2, screen.get_height()//5 - menu_text.get_height()//2))
        mouse_pos = pygame.mouse.get_pos()
        draw_button(button3_rect, "Pokračovat", mouse_pos)
        draw_button(button2_rect, "Nastavení", mouse_pos)
        draw_button(button_rect, "Konec hry", mouse_pos)

    pygame.display.flip()

pygame.quit()
sys.exit()
