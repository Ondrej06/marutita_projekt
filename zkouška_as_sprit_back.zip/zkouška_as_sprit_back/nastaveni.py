import pygame
import sys
import numpy as np

class SettingsMenu:
    def __init__(self, screen_width=1280, screen_height=720):
        pygame.init()
        
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.screen = pygame.display.set_mode((screen_width, screen_height))
        pygame.display.set_caption("Nastavení - Rozlišení a Hlasitost")
        
        # Barvy a fonty
        self.BG_COLOR = (20, 25, 40)
        self.CARD_COLOR = (35, 45, 65)
        self.ACCENT_COLOR = (86, 98, 246)
        self.ACCENT_HOVER = (106, 118, 255)
        self.BUTTON_COLOR = (45, 55, 85)
        self.BUTTON_HOVER = (65, 75, 115)
        self.TEXT_COLOR = (240, 245, 255)
        self.SECONDARY_TEXT = (180, 190, 210)
        self.SLIDER_BG = (50, 60, 90)
        self.SLIDER_FG = self.ACCENT_COLOR

        self.title_font = pygame.font.Font(None, 60)
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 28)
        
        # Hlasitost a slider
        self.volume = 0.4
        self.dragging_slider = False
        self.last_beep_time = 0  # čas posledního přehrání beep
        
        # Zvukový feedback
        self.beep_sound = self.create_beep_sound()
        self.beep_sound.set_volume(self.volume)
        
        # UI prvky
        self.resolution_buttons = self.create_resolution_buttons()
        self.slider_rect, self.plus_button, self.minus_button = self.create_slider_elements()
        
        self.running = True
        self.clock = pygame.time.Clock()
        
        self.on_resolution_change = None
        self.on_volume_change = None
    
    def create_beep_sound(self):
        SAMPLE_RATE = 44100
        DURATION = 0.1
        FREQ = 440
        t = np.linspace(0, DURATION, int(SAMPLE_RATE * DURATION), False)
        wave = 0.5 * np.sin(2 * np.pi * FREQ * t)
        sound_array = np.int16(wave * 32767)
        sound_array = np.column_stack([sound_array, sound_array])  # stereo
        return pygame.sndarray.make_sound(sound_array)
    
    def create_resolution_buttons(self):
        button_width, button_height = 250, 60
        spacing = 15
        start_y = 200
        buttons = {}
        resolutions = [(1920, 1080), (1600, 900), (1280, 720)]
        left_x = 50  # levá strana
        for i, res in enumerate(resolutions):
            rect = pygame.Rect(left_x, start_y + i * (button_height + spacing), button_width, button_height)
            buttons[f"{res[0]} × {res[1]}"] = [rect, res]
        return buttons
    
    def create_slider_elements(self):
        slider_width = 300
        right_x = self.screen_width - slider_width - 100  # pravá strana
        slider_rect = pygame.Rect(right_x, 300, slider_width, 12)
        plus_button = pygame.Rect(slider_rect.right + 15, slider_rect.y - 15, 50, 40)
        minus_button = pygame.Rect(slider_rect.left - 65, slider_rect.y - 15, 50, 40)
        return slider_rect, plus_button, minus_button
    
    def draw_speaker_icon(self, x, y, size=30):
        pygame.draw.rect(self.screen, self.SECONDARY_TEXT, (x, y + size//4, size//2, size//2), border_radius=3)
        pygame.draw.rect(self.screen, self.SECONDARY_TEXT, (x + size//2, y + size//3, size//3, size//3), border_radius=2)
        for i in range(1, 4):
            pygame.draw.arc(self.screen, self.SECONDARY_TEXT, (x + size//2 - 5, y - i*3, size + i*6, size + i*6), -0.7, 0.7, 2)
    
    def draw_resolution_buttons(self):
        title = self.font.render("Výběr rozlišení", True, self.TEXT_COLOR)
        self.screen.blit(title, (50, 150))
        for text, (rect, _) in self.resolution_buttons.items():
            mouse_pos = pygame.mouse.get_pos()
            is_hovered = rect.collidepoint(mouse_pos)
            pygame.draw.rect(self.screen, self.BUTTON_HOVER if is_hovered else self.BUTTON_COLOR, rect, border_radius=12)
            label = self.font.render(text, True, self.TEXT_COLOR)
            self.screen.blit(label, label.get_rect(center=rect.center))
            if (self.screen_width, self.screen_height) == self.resolution_buttons[text][1]:
                check_mark = self.font.render("✓", True, self.ACCENT_COLOR)
                self.screen.blit(check_mark, (rect.right - 30, rect.centery - check_mark.get_height()//2))
    
    def draw_slider(self):
        title = self.font.render("Hlasitost", True, self.TEXT_COLOR)
        self.screen.blit(title, (self.slider_rect.x, 250))
        self.draw_speaker_icon(self.slider_rect.x - 60, self.slider_rect.y - 10)
        pygame.draw.rect(self.screen, self.SLIDER_BG, self.slider_rect, border_radius=6)
        filled_width = int(self.slider_rect.width * self.volume)
        pygame.draw.rect(self.screen, self.SLIDER_FG, (self.slider_rect.x, self.slider_rect.y, filled_width, self.slider_rect.height), border_radius=6)
        handle_x = self.slider_rect.x + filled_width
        pygame.draw.rect(self.screen, self.TEXT_COLOR, (handle_x - 8, self.slider_rect.y - 8, 16, 28), border_radius=8)
        vol_text = self.font.render(f"{int(self.volume*100)}%", True, self.TEXT_COLOR)
        self.screen.blit(vol_text, (self.slider_rect.right + 50, self.slider_rect.centery - vol_text.get_height()//2))
        for btn_rect, symbol in [(self.plus_button, "+"), (self.minus_button, "-")]:
            is_hovered = btn_rect.collidepoint(pygame.mouse.get_pos())
            color = self.ACCENT_HOVER if is_hovered else self.ACCENT_COLOR
            pygame.draw.rect(self.screen, color, btn_rect, border_radius=8)
            self.screen.blit(self.font.render(symbol, True, self.TEXT_COLOR), self.font.render(symbol, True, self.TEXT_COLOR).get_rect(center=btn_rect.center))
    
    def handle_events(self):
        now = pygame.time.get_ticks()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False   # zavře nastavení a vrátí tě zpátky


            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # plus/minus
                if self.plus_button.collidepoint(event.pos):
                    self.volume = min(1.0, self.volume + 0.05)
                    self.beep_sound.set_volume(self.volume)
                    self.beep_sound.play()
                    if self.on_volume_change: self.on_volume_change(self.volume)
                elif self.minus_button.collidepoint(event.pos):
                    self.volume = max(0.0, self.volume - 0.05)
                    self.beep_sound.set_volume(self.volume)
                    self.beep_sound.play()
                    if self.on_volume_change: self.on_volume_change(self.volume)
                # slider
                elif self.slider_rect.collidepoint(event.pos):
                    self.dragging_slider = True
                    rel_x = event.pos[0] - self.slider_rect.x
                    self.volume = max(0, min(1, rel_x / self.slider_rect.width))
                    self.beep_sound.set_volume(self.volume)
                    if now - self.last_beep_time > 100: self.beep_sound.play(); self.last_beep_time = now
                    if self.on_volume_change: self.on_volume_change(self.volume)
                # rozlišení
                else:
                    for text, (rect, res) in self.resolution_buttons.items():
                        if rect.collidepoint(event.pos):
                            self.screen_width, self.screen_height = res
                            if res == (1920, 1080):
                                self.screen = pygame.display.set_mode(res, pygame.FULLSCREEN)
                            else:
                                self.screen = pygame.display.set_mode(res)
                            self.resolution_buttons = self.create_resolution_buttons()
                            self.slider_rect, self.plus_button, self.minus_button = self.create_slider_elements()
                            if self.on_resolution_change: self.on_resolution_change(res)
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                self.dragging_slider = False
            if event.type == pygame.MOUSEMOTION and self.dragging_slider:
                rel_x = event.pos[0] - self.slider_rect.x
                self.volume = max(0, min(1, rel_x / self.slider_rect.width))
                self.beep_sound.set_volume(self.volume)
                if now - self.last_beep_time > 100:
                    self.beep_sound.play(); self.last_beep_time = now
                if self.on_volume_change: self.on_volume_change(self.volume)
        return True
    
    def update(self):
        self.screen.fill(self.BG_COLOR)
        self.draw_resolution_buttons()
        self.draw_slider()
        footer_text = self.small_font.render("Použijte tlačítka nebo slider pro nastavení", True, self.SECONDARY_TEXT)
        self.screen.blit(footer_text, (self.screen_width//2 - footer_text.get_width()//2, self.screen_height - 50))
        pygame.display.flip()
        self.clock.tick(60)
    
    def run(self):
        self.running = True
        while self.running:
            self.running = self.handle_events()
            self.update()
        # žádné pygame.quit ani sys.exit tady
    
    def set_callbacks(self, on_resolution_change=None, on_volume_change=None):
        self.on_resolution_change = on_resolution_change
        self.on_volume_change = on_volume_change


# Příklad
if __name__ == "__main__":
    def on_res_change(res): print(f"Rozlišení: {res}")
    def on_vol_change(vol): print(f"Hlasitost: {int(vol*100)}%")
    
    menu = SettingsMenu()
    menu.set_callbacks(on_res_change, on_vol_change)
    menu.run()
