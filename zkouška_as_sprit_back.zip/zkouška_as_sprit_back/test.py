import pygame
import sys
import math
import time
import random
from character_test import Character
from nastaveni import SettingsMenu  # tvoje SettingsMenu třída

pygame.init()

# === Výchozí nastavení ===
SCREEN_WIDTH, SCREEN_HEIGHT = 1920, 1080
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Platformer + Boss")
clock = pygame.time.Clock()

state = "game"

# === Fonty a tlačítka ===
font = pygame.font.SysFont("Arial", 100)
button_font = pygame.font.SysFont("Arial", 50)
button_hover_font = pygame.font.SysFont("Arial", 70)
button_color = (0, 0, 0)
button_hover_color = (50, 50, 50)

def draw_button(rect, text, mouse_pos):
    if rect.collidepoint(mouse_pos):
        pygame.draw.rect(screen, button_hover_color, rect)
        text_surface = button_hover_font.render(text, True, (255, 255, 255))
    else:
        pygame.draw.rect(screen, button_color, rect)
        text_surface = button_font.render(text, True, (255, 255, 255))
    text_rect = text_surface.get_rect(center=rect.center)
    screen.blit(text_surface, text_rect)

def hud(screen, player, potions_left, potion_icon, heart_full, heart_empty):
    total_hearts = int(player.max_health // 10)
    full_hearts = max(0, int(player.health // 10))
    heart_size = 40
    spacing = 10
    start_x = 20
    y = 20

    for i in range(total_hearts):
        x = start_x + i * (heart_size + spacing)
        if heart_full and heart_empty:
            if i < full_hearts:
                screen.blit(heart_full, (x, y))
            else:
                screen.blit(heart_empty, (x, y))
        else:
            color = (255, 0, 0) if i < full_hearts else (40, 40, 40)
            pygame.draw.rect(screen, color, (x, y, heart_size, heart_size))

    potion_area_x = 20
    potion_area_y = y + heart_size + 40
    if potion_icon:
        screen.blit(potion_icon, (potion_area_x, potion_area_y))
    else:
        pygame.draw.circle(screen, (200, 0, 0), (potion_area_x + 30, potion_area_y + 30), 30)

    pot_text = button_font.render(f"x {potions_left}", True, (255, 255, 255))
    screen.blit(pot_text, (potion_area_x + 80, potion_area_y + 10))

def get_ground_y(width):
    if width == 1920: return 950
    elif width == 1600: return 800
    elif width == 1280: return 600
    return 600

ground_y = get_ground_y(SCREEN_WIDTH)

# === Player ===
player = Character(400, 0, scale=2, frame_size=128, ground_y=ground_y)
player.health = 50
player.max_health = 100
health_potions = 3
health_potion_heal = 30
speed = 5 
run_multiplier = 2
is_jumping = False
jump_speed = 18 
gravity_player = 1 
velocity_y = 0
attacking = False
attack_cooldown = 0.5
attack_timer = 0

dashing = False
dash_speed = 22
dash_duration = 0.2
dash_timer = 0
dash_cooldown = 1.0
dash_cooldown_timer = 0
dash_trail = []
trail_timer = 0

jump_count = 0
max_jumps = 2

potion_used = False
heal_effect_timer = 0
heal_aura_max_radius = 80

# === Boss ===
boss_pos = [800.0, 300.0]
boss_radius = 50
boss_color = (255, 0, 0)
boss_speed = 20
wait_duration = 1.0
targets = [
    (479, 337), (1509, 547), (983, 608), (992, 76),
    (479, 337), (1509, 547), (983, 608), (479, 337),
    (1509, 547), (479, 337)
]
current_target_index = 0
waiting = False
wait_start_time = 0

# Projectiles
projectiles = []
projectile_speed = 10
projectile_radius = 8
shoot_interval = 2.5
last_shot_time = 0
homing_delay = 0.5
projectiles_per_shot = 400
trail_length = 10

# === Ikony ===
try:
    potion_icon = pygame.image.load("assets/UI/Transperent/Icon23.png").convert_alpha()
    potion_icon = pygame.transform.scale(potion_icon, (60, 60))
except: potion_icon = None

try:
    heart_full = pygame.image.load("assets/UI/heart.png").convert_alpha()
    heart_empty = pygame.image.load("assets/UI/heart_black.png").convert_alpha()
    heart_full = pygame.transform.scale(heart_full, (40, 40))
    heart_empty = pygame.transform.scale(heart_empty, (40, 40))
except: heart_full = heart_empty = None

# --- Callbacks ---
def on_res_change(res):
    global screen, SCREEN_WIDTH, SCREEN_HEIGHT, ground_y
    SCREEN_WIDTH, SCREEN_HEIGHT = res
    screen = pygame.display.set_mode(res)
    ground_y = get_ground_y(SCREEN_WIDTH)
    player.ground_y = ground_y

def on_vol_change(vol):
    pygame.mixer.music.set_volume(vol)

# --- Main Loop ---
running = True
while running:
    dt = clock.tick(60)/1000
    keys = pygame.key.get_pressed()

    # --- Event handling ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                state = "menu" if state=="game" else "game"
            if state=="game" and event.key==pygame.K_SPACE and jump_count<max_jumps:
                velocity_y = -jump_speed
                is_jumping = True
                jump_count += 1
            if state=="game" and event.key==pygame.K_LCTRL and not dashing and dash_cooldown_timer==0:
                dashing = True
                dash_timer = dash_duration
                dash_cooldown_timer = dash_cooldown

    if dash_cooldown_timer > 0:
        dash_cooldown_timer -= dt
        if dash_cooldown_timer < 0: dash_cooldown_timer = 0

    # --- Game logic ---
    if state=="game":
        # Player potion
        if not potion_used and keys[pygame.K_f] and health_potions>0:
            potion_used = True
            health_potions -= 1
            player.health += health_potion_heal
            if player.health>player.max_health: player.health=player.max_health
            heal_effect_timer = 1.0
        if not keys[pygame.K_f]: potion_used=False

        # Player movement
        moving = False
        current_speed = speed * (run_multiplier if keys[pygame.K_LSHIFT] else 1)
        if not dashing:
            if keys[pygame.K_a]:
                player.rect.x -= current_speed
                moving = True
                player.facing_right = False
            if keys[pygame.K_d]:
                player.rect.x += current_speed
                moving = True
                player.facing_right = True

        # Dash
        if dashing:
            player.rect.x += dash_speed if player.facing_right else -dash_speed
            trail_timer += dt
            if trail_timer>=0.05:
                trail_timer=0
                dash_trail.append([player.image.copy(), player.rect.topleft, 255])
            dash_timer -= dt
            if dash_timer<=0: dashing=False
        for ghost in dash_trail: ghost[2]-=10
        dash_trail = [g for g in dash_trail if g[2]>0]

        # Gravity
        player.rect.y += velocity_y
        velocity_y += gravity_player
        if player.rect.bottom >= ground_y:
            player.rect.bottom = ground_y
            is_jumping=False
            velocity_y=0
            jump_count=0

        # Player attack
        if attack_timer>0: attack_timer-=dt
        else: attack_timer=0
        if not attacking and attack_timer==0:
            if keys[pygame.K_q]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_1")
            elif keys[pygame.K_w]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_2")
            elif keys[pygame.K_e]: attacking=True; attack_timer=attack_cooldown; player.start_attack("Attack_3")
        player.update()
        if attacking and int(player.current_frame)==len(player.frames)-1:
            attacking=False
            player.end_attack()
        if not attacking:
            if is_jumping: player.set_animation("Jump")
            elif moving: player.set_animation("Run" if keys[pygame.K_LSHIFT] else "Walk")
            else: player.set_animation("Idle")

        # --- Boss logic ---
        if not waiting:
            target_pos = targets[current_target_index]
            dx = target_pos[0] - boss_pos[0]
            dy = target_pos[1] - boss_pos[1]
            distance = math.hypot(dx, dy)
            if distance > boss_speed:
                dx /= distance
                dy /= distance
                boss_pos[0] += dx * boss_speed
                boss_pos[1] += dy * boss_speed
            else:
                boss_pos[0], boss_pos[1] = target_pos
                waiting = True
                wait_start_time = time.time()
        else:
            if time.time() - wait_start_time >= wait_duration:
                current_target_index = (current_target_index + 1) % len(targets)
                waiting = False

        # Boss shooting
        if time.time() - last_shot_time >= shoot_interval:
            for _ in range(projectiles_per_shot):
                angle = random.uniform(0, 360)
                rad = math.radians(angle)
                vx = projectile_speed * math.cos(rad)
                vy = projectile_speed * math.sin(rad)
                color = (
                    random.randint(50, 255),
                    random.randint(50, 255),
                    random.randint(50, 255)
                )
                projectiles.append({
                    'pos': [boss_pos[0], boss_pos[1]],
                    'vel': [vx, vy],
                    'spawn_time': time.time(),
                    'color': color,
                    'homing_done': False,
                    'trail': []
                })
            last_shot_time = time.time()

        # Projectiles
        for p in projectiles[:]:
            if not p['homing_done'] and time.time() - p['spawn_time'] >= homing_delay:
                dx = player.rect.centerx - p['pos'][0]
                dy = player.rect.centery - p['pos'][1]
                dist = math.hypot(dx, dy)
                if dist != 0:
                    dx /= dist
                    dy /= dist
                    p['vel'][0] = dx * projectile_speed
                    p['vel'][1] = dy * projectile_speed
                p['homing_done'] = True
            p['trail'].append((p['pos'][0], p['pos'][1]))
            if len(p['trail']) > trail_length:
                p['trail'].pop(0)
            p['pos'][0] += p['vel'][0]
            p['pos'][1] += p['vel'][1]
            if p['pos'][0] < 0 or p['pos'][0] > SCREEN_WIDTH or p['pos'][1] < 0 or p['pos'][1] > SCREEN_HEIGHT:
                projectiles.remove(p)

    # --- Drawing ---
    screen.fill((30, 30, 30))
    pygame.draw.rect(screen, (100, 100, 100), (0, ground_y, SCREEN_WIDTH, 50))

    if state=="game":
        hud(screen, player, health_potions, potion_icon, heart_full, heart_empty)

        # Heal aura
        if heal_effect_timer>0:
            heal_effect_timer -= dt
            alpha = int((heal_effect_timer/1.0)*150)
            radius = int((1-heal_effect_timer/1.0)*heal_aura_max_radius)+20
            aura_surface = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
            pygame.draw.circle(aura_surface, (0,255,0,alpha), (radius,radius), radius)
            screen.blit(aura_surface, (player.rect.centerx-radius, player.rect.centery-radius))

        # Dash trail
        for ghost_image, pos, alpha in dash_trail:
            surf = ghost_image.copy()
            surf.set_alpha(alpha)
            screen.blit(surf, pos)

        # Player
        player.draw(screen)

        # Boss
        pygame.draw.circle(screen, boss_color, (int(boss_pos[0]), int(boss_pos[1])), boss_radius)

        # Projectiles
        for p in projectiles:
            if len(p['trail']) > 1:
                for i in range(1, len(p['trail'])):
                    start = p['trail'][i-1]
                    end = p['trail'][i]
                    factor = i / len(p['trail'])
                    color = (
                        int(p['color'][0] * factor),
                        int(p['color'][1] * factor),
                        int(p['color'][2] * factor)
                    )
                    pulse = 1 + int(2 * math.sin(time.time() * 10 + i))
                    width = max(1, int(3 * factor + pulse))
                    pygame.draw.line(screen, color, start, end, width)
            pygame.draw.circle(screen, p['color'], (int(p['pos'][0]), int(p['pos'][1])), projectile_radius)

    elif state=="menu":
        menu_text = font.render("MENU", True, (255,0,0))
        screen.blit(menu_text, (SCREEN_WIDTH//2 - menu_text.get_width()//2, SCREEN_HEIGHT//5 - menu_text.get_height()//2))

    pygame.display.flip()

pygame.quit()
sys.exit()
